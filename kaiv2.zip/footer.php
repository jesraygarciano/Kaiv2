
	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="<?php echo get_bloginfo('template_directory'); ?>/js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="<?php echo get_bloginfo('template_directory'); ?>/js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="<?php echo get_bloginfo('template_directory'); ?>/js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="<?php echo get_bloginfo('template_directory'); ?>/js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="<?php echo get_bloginfo('template_directory'); ?>/js/owl.carousel.min.js"></script>

	<!-- Main -->
	<script src="<?php echo get_bloginfo('template_directory'); ?>/js/main.js"></script>

	</body>
</html>